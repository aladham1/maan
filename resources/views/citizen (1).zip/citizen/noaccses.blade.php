@extends("layouts._citizen_layout")

@section("title", "متابعة نموذج ")

@section("content")
<div class="container">
    <div class="row" style="text-align:center;">
<div class="col-sm-12">
        <h2 style="margin-top:120px;margin-bottom:30px;color:#af0922;">يرجى التأكد من صحة الرابط المراد الوصول له</h2>

</div>
</div>
</div>
@endsection