@extends("layouts._citizen_layout")

@section("title", "متابعة نموذج ")


@section("content")

    <div class="row" style="text-align:center;">

        <h2 class="col-sm-6" style="margin-top:120px;margin-bottom:30px;color:#af0922;margin-left:337px;">يرجى التأكد من صحة الرابط المراد الوصول له</h2>

</div>
<br><br><br><br><br><br>
    <br><br><br><br><br><br>
    <br>
<!--***** first tab *****-->
</div>

<!--****************************************************** start footer **************************************************************-->
@endsection